<?php
namespace App\OtusBudget;

use Bitrix\Iblock\Elements\ElementTable;

class ProjectTable extends ElementTable
{
    public static function getTableName()
    {
        return 'b_iblock_element';
    }
}