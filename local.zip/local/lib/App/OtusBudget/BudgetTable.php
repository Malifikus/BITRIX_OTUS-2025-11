<?php
namespace App\OtusBudget;

use Bitrix\Main\ORM\DataManager;
use Bitrix\Main\ORM\Fields\IntegerField;
use Bitrix\Main\ORM\Fields\FloatField;
use Bitrix\Main\ORM\Fields\StringField;
use Bitrix\Main\ORM\Fields\Relations\Reference;

class BudgetTable extends DataManager
{
    public static function getTableName()
    {
        return 'app_otus_budgets';
    }

    public static function getMap()
    {
        return [
            new IntegerField('ID', [
                'primary' => true,
                'autocomplete' => true
            ]),
            new IntegerField('PROJECT_ID'),
            new IntegerField('DEPARTMENT_ID'),
            new FloatField('AMOUNT'),
            new StringField('DESCRIPTION'),
        ];
    }

    public static function query()
    {
        return parent::query()
            ->registerRuntimeField(new Reference(
                'PROJECT',
                \App\OtusBudget\ProjectTable::class,
                ['=this.PROJECT_ID' => 'ref.ID']
            ))
            ->registerRuntimeField(new Reference(
                'DEPARTMENT',
                \App\OtusBudget\DepartmentTable::class,
                ['=this.DEPARTMENT_ID' => 'ref.ID']
            ));
    }
}