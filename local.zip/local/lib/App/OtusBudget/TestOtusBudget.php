<?php
require $_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_before.php';

use OtusBudget\Test;

try {
    $test = new Test();
    echo "<h2> Ок</h2>";
    echo "<p>" . htmlspecialchars($test->hello()) . "</p>";
} catch (Error $e) {
    echo "<h2> Ошибка</h2>";
    echo "<p>Класс не найден: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<ul>";
    echo "<li>Путь к файлу: <code>/local/lib/OtusBudget/Test.php</code></li>";
    echo "<li>Namespace в файле: <code>namespace OtusBudget;</code></li>";
    echo "<li>Имя класса: <code>class Test</code></li>";
    echo "</ul>";
}