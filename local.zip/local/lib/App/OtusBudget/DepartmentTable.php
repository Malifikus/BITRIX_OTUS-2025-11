<?php
namespace App\OtusBudget;

use Bitrix\Iblock\Elements\ElementTable;

class DepartmentTable extends ElementTable
{
    public static function getTableName()
    {
        return 'b_iblock_element';
    }
}