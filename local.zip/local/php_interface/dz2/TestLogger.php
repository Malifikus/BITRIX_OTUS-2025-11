<?php

define("NO_KEEP_STATISTIC", true);
define("NOT_CHECK_PERMISSIONS", true);

file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/local/logs/otus_system.log', "OTUS: Тест\n", FILE_APPEND | LOCK_EX);
throw new Exception("Тест");