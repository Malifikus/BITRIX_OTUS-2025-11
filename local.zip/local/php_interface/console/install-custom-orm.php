<?php
# Стандартный шаблон для инсталляционных скриптов в Битрикс
if (php_sapi_name () != 'cli')
    {
        die();
    }

define ("NO_KEEP_STATISTIC", true);
define ("NOT_CHECK_PERMISSIONS", true);
define ("BX_CRONTAB", true);
define ("BX_NO_ACCELERATOR_RESET", true)
define ("NO_AGENT_CHECK", true);
define ("DisableEventsCheck", true);
define ("STOP_STATISTICS", true);
define ("NO_AGENT_STATISTIC", "Y");

# Путь к корню проекта
$_SERVER["DOCUMENT_ROOT"] = realpath('/home/c/cw976115/Malifikus/public_html');
require_once($_SERVER["DOCUMENT_ROOT"] . '/bitrix/modules/main/include/prolog_before.php');

use Bitrix\Main\Entity\Base;
use Bitrix\Main\Application;
#
# Здесь будет указание своих кастомных ORM
#