<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

return [
    'js' => ['./search.title.js'],
    // CSS подключаем через rel
    'rel' => [
        'main.core',
        'main.core.loc',
        'ajax',
        'finder',
        'ui.buttons',
        'ui.buttons.icons',
        // Модули для расширенного поиска
        'crm.api.entity.search', 
        'disk.commonActions.search',
        'tasks.task.search'
    ],
    'skip_core' => false,
];