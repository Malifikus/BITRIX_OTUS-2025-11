<?php

class OTUSFileExceptionHandlerLog extends \Bitrix\Main\Diag\ExceptionHandlerLog
{
    protected string $filePath;

    public function initialize(array $settings = []): void
    {
        $logPath = $settings['file'] ?? '/local/logs/otus_system.log';
        $this->filePath = $_SERVER['DOCUMENT_ROOT'] . $logPath;

        $logDir = dirname($this->filePath);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }
    }

    public function write($exception, $logType = 0): void
    {
        $message = sprintf(
            "[%s] %s (%s:%d)\n%s",
            date('Y-m-d H:i:s'),
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine(),
            $exception->getTraceAsString()
        );

        file_put_contents($this->filePath, $message, FILE_APPEND | LOCK_EX);
    }
}