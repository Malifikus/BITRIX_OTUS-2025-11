<?
$sSectionName="bitrix";
?>